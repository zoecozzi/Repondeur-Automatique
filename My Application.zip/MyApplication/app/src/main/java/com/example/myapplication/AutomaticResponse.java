package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class AutomaticResponse extends AppCompatActivity {

    private static final String PREFS_NAME = "MyPrefsFile";
    private ArrayList<String> predefinedMessages;
    private ArrayAdapter<String> adapter;
    private View previousSelectedView = null;
    private ListView listViewAutomaticResponses;
    private int selectedMessageIndex = -1;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.automatic_response);

        // Récupération de la liste des contacts sélectionnés
        Intent intent = getIntent();
        ArrayList<String> selectedContacts = intent.getStringArrayListExtra("selectedContacts");

        // Affichage de la liste des contacts sélectionnés dans le TextView
        TextView textViewSelectedContacts = findViewById(R.id.text_view_selected_contacts);
        StringBuilder stringBuilder = new StringBuilder();
        for (String contact : selectedContacts) {
            stringBuilder.append(contact).append("\n");
        }
        textViewSelectedContacts.setText(stringBuilder.toString());

        // Récupération de la liste des messages pré-enregistrés
        SharedPreferences sharedPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        predefinedMessages = new ArrayList<>(sharedPrefs.getStringSet("predefinedMessages", new HashSet<>()));

        // Affichage de la liste des messages pré-enregistrés dans le ListView
        listViewAutomaticResponses = findViewById(R.id.list_view_automatic_responses);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, predefinedMessages);
        listViewAutomaticResponses.setAdapter(adapter);

        // Ajout de l'événement onClickListener sur le bouton "+" pour ajouter de nouveaux messages
        Button addButton = findViewById(R.id.button_add_message);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayAddMessageDialog();
            }
        });


        listViewAutomaticResponses.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(AutomaticResponse.this);
                builder.setTitle("Modifier ou supprimer le message ?");
                builder.setPositiveButton("Modifier", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Affichage de la boîte de dialogue pour modifier le message
                        displayEditMessageDialog(position);
                    }
                });
                builder.setNegativeButton("Supprimer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Suppression du message
                        predefinedMessages.remove(position);
                        adapter.notifyDataSetChanged();

                        // Mise à jour des préférences partagées
                        SharedPreferences sharedPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPrefs.edit();
                        Set<String> set = new HashSet<>(predefinedMessages);
                        editor.putStringSet("predefinedMessages", set);
                        editor.apply();
                    }
                });
                builder.show();
                return true;
            }
        });

        listViewAutomaticResponses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                if(previousSelectedView != null){
                    // Change the color of the previously selected view back to its original color
                    previousSelectedView.setBackgroundColor(getResources().getColor(android.R.color.transparent));
                }
                // Change the color of the newly selected view
                view.setBackgroundColor(getResources().getColor(R.color.lightGray));
                // Update the index of the selected message
                selectedMessageIndex = position;
                // Set the newly selected view as the previous selected view
                previousSelectedView = view;
            }
        });

        Button sendButton = findViewById(R.id.button_send);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Vérifiez si un message a été sélectionné
                if (selectedMessageIndex != -1) {
                    // Récupérez le message sélectionné
                    String message = predefinedMessages.get(selectedMessageIndex);

                    // Envoyez le message à la liste des contacts sélectionnés
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, message);
                    sendIntent.setType("text/plain");
                    sendIntent.putExtra("selectedContacts", selectedContacts);
                    sendIntent.setPackage("com.android.messages");
                    startActivity(sendIntent);
                } else {
                    // Si aucun message n'a été sélectionné, affichez un message d'erreur
                    Toast.makeText(AutomaticResponse.this, "Veuillez sélectionner un message à envoyer.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Affichage de la boîte de dialogue pour modifier un message existant
    private void displayEditMessageDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Modifier le message");

        // Zone de saisie pour le message existant
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(predefinedMessages.get(position));
        builder.setView(input);

        // Bouton OK pour enregistrer le message modifié
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String message = input.getText().toString();
                predefinedMessages.set(position, message);
                adapter.notifyDataSetChanged();

                // Enregistrement du message modifié dans les préférences partagées
                SharedPreferences sharedPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPrefs.edit();
                Set<String> set = new HashSet<>(predefinedMessages);
                editor.putStringSet("predefinedMessages", set);
                editor.apply();
            }
        });

        // Bouton Annuler pour fermer la boîte de dialogue
        builder.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    // Affichage de la boîte de dialogue pour ajouter un nouveau message
    private void displayAddMessageDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Ajouter un nouveau message");

        // Zone de saisie pour le nouveau message
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Bouton OK pour enregistrer le nouveau message
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String message = input.getText().toString();
                predefinedMessages.add(message);
                adapter.notifyDataSetChanged();

                // Enregistrement du nouveau message dans les préférences partagées
                SharedPreferences sharedPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPrefs.edit();
                Set<String> set = new HashSet<>(predefinedMessages);
                editor.putStringSet("predefinedMessages", set);
                editor.apply();
            }
        });

        // Bouton Annuler pour fermer la boîte de dialogue
        builder.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }
}
