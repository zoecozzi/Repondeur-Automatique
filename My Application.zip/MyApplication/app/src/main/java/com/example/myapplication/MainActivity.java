package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myapplication.AutomaticResponse;
import com.example.myapplication.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> selectedContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Récupération du bouton
        Button btnWrite = findViewById(R.id.btnWrite);
        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Code à exécuter lorsque le bouton est cliqué
                Intent intent = new Intent(MainActivity.this, AutomaticResponse.class);
                intent.putExtra("selectedContacts", selectedContacts); // selectedContacts est la liste des contacts sélectionnés
                startActivity(intent);
            }
        });

        selectedContacts = new ArrayList<>();
        recupContacts();
    }

    /*
     * Récupération des contacts dans le mobile
     * */
    public void recupContacts(){
        //accès au contenu du mobile
        ContentResolver contentResolver = this.getContentResolver();
        //Récupération des contats dans un curseur
        Cursor cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[] { ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_ALTERNATIVE,
                        ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
        if (cursor == null){
            Log.d("recup",
                    "************ erreur curseur");
        } else{
            LinearLayout contactList = (LinearLayout) findViewById(R.id.contact_list);
            LayoutInflater inflater = LayoutInflater.from(this);
            //parcours des contacts
            while(cursor.moveToNext()){
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_ALTERNATIVE));
                String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                //création de la vue contact avec nom, numéro et checkbox
                View contactView = inflater.inflate(R.layout.contact_item, contactList, false);
                TextView nameView = (TextView) contactView.findViewById(R.id.txtName);
                TextView phoneView = (TextView) contactView.findViewById(R.id.txtPhone);
                CheckBox checkBox = (CheckBox) contactView.findViewById(R.id.chkContact);
                nameView.setText(name);
                phoneView.setText(phone);
                //ajout de la vue contact à la liste
                contactList.addView(contactView);

                // Ajout d'un listener sur la checkbox pour ajouter/supprimer le contact sélectionné
                checkBox.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (checkBox.isChecked()) {
                            selectedContacts.add(name + " (" + phone + ")");
                        } else {
                            selectedContacts.remove(name + " (" + phone + ")");
                        }
                    }
                });
            }
            //fermer le curseur
            cursor.close();
        }
    }
}
